import subprocess
from datetime import datetime

from appium import webdriver
from appium.options.common.base import AppiumOptions
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

id_device = ''
account_name = ''
ma_khach_hangs = []
tiens = []
def run(id_device, account_name, ma_khach_hangs):
    try:
        for ma_khach_hang in ma_khach_hangs:
            thoi_gian = datetime.now()
            thoi_gian_hien_tai = thoi_gian.strftime("%H-%M-%S_%d-%m-%Y")
            options = AppiumOptions()
            options.load_capabilities({
                "appium:uuid": id_device,
                "platformName": "Android",
                "appium:automationName": "UiAutomator2"
            })

            driver = webdriver.Remote("http://192.168.100.48:4723", options=options)
            wait = WebDriverWait(driver, 10)
            thanh_toan_hoa_don = driver.find_element(
                by=AppiumBy.XPATH, value="(//android.widget.ImageView[@resource-id=\"com.vnpay.vpbankonline:id/icon\"])[1]")
            thanh_toan_hoa_don.click()
            hoa_don_tien_dien = (
                AppiumBy.XPATH, "(//android.widget.ImageView[@resource-id='com.vnpay.vpbankonline:id/icon'])[1]")
            icon_hoa_don_dien = wait.until(
                EC.presence_of_element_located(hoa_don_tien_dien))
            icon_hoa_don_dien.click()
            nha_cung_cap = (
                AppiumBy.XPATH, "//android.widget.LinearLayout[@resource-id=\"com.vnpay.vpbankonline:id/mainLayout\"]/android.widget.LinearLayout")
            icon_nha_cung_cap = wait.until(EC.presence_of_element_located(nha_cung_cap))
            icon_nha_cung_cap.click()
            dien_luc_toan_quoc = driver.find_element(
                by=AppiumBy.XPATH, value='//androidx.recyclerview.widget.RecyclerView[@resource-id="com.vnpay.vpbankonline:id/rvList"]/android.widget.LinearLayout[4]')
            dien_luc_toan_quoc.click()
            tai_khoan_nguon = driver.find_element(
                by=AppiumBy.XPATH, value="//android.widget.LinearLayout[@resource-id=\"com.vnpay.vpbankonline:id/selectAccount\"]/android.widget.LinearLayout/android.widget.LinearLayout")
            tai_khoan_nguon.click()

            def chon_tai_khoan_nguon(account_name):
                valid_input = False
                while not valid_input:
                    elements = driver.find_element(by=AppiumBy.XPATH, value="//android.widget.ListView[@resource-id='com.vnpay.vpbankonline:id/listAccount']") \
                        .find_elements(by=AppiumBy.CLASS_NAME, value="android.widget.TextView")
                    for element in elements:
                        if element.text == account_name:
                            valid_input = True
                            return element

            chon_tai_khoan_nguon(account_name).click()
            ma_khach_hang_input = driver.find_element(
                by=AppiumBy.XPATH, value='//android.widget.EditText[@resource-id="com.vnpay.vpbankonline:id/edtCustomerCode"]')
            ma_khach_hang_input.send_keys(ma_khach_hang)
            tiep_tuc_1 = driver.find_element(
                by=AppiumBy.XPATH, value='//androidx.cardview.widget.CardView[@resource-id="com.vnpay.vpbankonline:id/btnAction"]')
            tiep_tuc_1.click()
            so_tien_timeout = (
                AppiumBy.XPATH, '//android.widget.TextView[@resource-id="com.vnpay.vpbankonline:id/tvTotalAmount"]')
            so_tien = wait.until(EC.presence_of_element_located(so_tien_timeout))

            tiep_tuc_2 = driver.find_element(
                by=AppiumBy.XPATH, value='//android.widget.TextView[@resource-id="com.vnpay.vpbankonline:id/tvTitleAction"]')
            tiep_tuc_2.click()
            tien = "Số tiền: " + so_tien.text
            tiens.append(tien)
            subprocess.run(['adb', '-s', '9ca06bc0', 'shell',
                        'screencap', '-p', '/sdcard/screenshot.png'])
            subprocess.run(['adb', '-s', '9ca06bc0', 'pull',
                        '/sdcard/screenshot.png', f'./images/{ma_khach_hang}/{thoi_gian_hien_tai}.png'])
            giao_dich_moi = driver.find_element(
                by=AppiumBy.XPATH, value='//android.widget.LinearLayout[@resource-id="com.vnpay.vpbankonline:id/vMakeOtherPayment"]')
            giao_dich_moi.click()
        driver.quit()
        return ma_khach_hangs, tiens
    except:
        return "Lỗi không xác định"
